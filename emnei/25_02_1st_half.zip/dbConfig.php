<?php

 $conn = mysql_connect("localhost", "root", "");
 $db = mysql_select_db("student_info_13batch", $conn);

?>