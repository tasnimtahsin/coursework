-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2017 at 02:54 PM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `student_info_13batch`
--

-- --------------------------------------------------------

--
-- Table structure for table `employes`
--

CREATE TABLE IF NOT EXISTS `employes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `age` varchar(128) NOT NULL,
  `salary` varchar(128) NOT NULL,
  `phone` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `address` varchar(128) NOT NULL,
  `department` varchar(128) NOT NULL,
  `position` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `employes`
--

INSERT INTO `employes` (`id`, `name`, `gender`, `age`, `salary`, `phone`, `email`, `address`, `department`, `position`, `image`) VALUES
(1, 'saeed mahmood', 'male', '27', '25000', '01671889896', 'saeedmahmood9896@gmail.com', 'kalabagan', 'web development', 'senior developer', 'download (1).jpg'),
(2, 'fateh mahmood', 'male', '20', '15000', '01727396775', 'fateh@gmail.com', 'banani', 'web development', 'junior developer', 'images.jpg'),
(3, 'sarmin', 'male', '22', '30000', '0199484845', 'sarmin@gmail.com', 'khulna', 'web development', 'senior developer', 'htc-desire-601-en_US-slide-01.png'),
(4, 'alrazi', 'male', '20', '30000', '0155989659', 'alrazi@gmail.com', 'khulna', 'software development', 'junior developer', 'download.jpg'),
(5, 'tania', 'female', '22', '35000', '0155557868', 'tania@ymail.com', 'gulshan', 'web development', 'junior developer', ''),
(6, 'jahir', 'male', '26', '28000', '0158989891', 'jahir@gmail.com', 'dhanmondi', 'management', 'assistance manager ', ''),
(14, 'najir', 'male', '29', '36000', '0164759859', 'najir@gmail.com', 'uttora', 'software development', 'assistance manager ', '227735_2110748012384_2103933_n.jpg'),
(16, 'mahbub', 'male', '34', '36000', '0155989659', 'mahbub@gmail.com', 'gulshan', 'web development', 'senior developer', 'IMG_6447.JPG'),
(17, 'noyn', 'male', '32', '18000', '0174685995', 'noyon@gmail.com', 'dhanmondi', 'management', 'assistance manager ', 'IMG_6446.JPG'),
(18, 'sabbir', 'male', '22', '30000', '0155236598', 'sabbir@gmail.com', 'razarbazar', 'software development', 'senior developer', '156052_10206412146806593_3334341888146435044_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'index id',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `address` varchar(255) NOT NULL,
  `age` varchar(40) NOT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `email`, `phone`, `gender`, `address`, `age`, `create_date`) VALUES
(1, 'Tashnim', 'tasnim@gmail.com', '018956655665', 'Male', 'Dhaka, Bangladesh', '15', '2017-02-24 13:44:14'),
(2, 'Mustak', 'm@gmail.com', '01923834492', 'Male', 'Dhaka', '14', '2017-02-24 14:04:07'),
(3, 'wewa', 'werwe', '457467567', 'Male', 'wer', 'werwe', '2017-02-24 15:07:39'),
(4, 'Lister Khan', 'listar@gmail.com', '01735302584', 'Male', 'Dhaka', '28', '2017-02-25 13:17:41'),
(5, 'Jony Sheikh PIIT', 'jonysheikhrtl@gmail.com', '01735302584', 'Male', 'Dhaka', '28', '2017-02-25 13:19:04'),
(6, 'abc', 'abc@gmail.com', '01735302584', 'Female', 'Dhaka', '28', '2017-02-25 13:21:49'),
(7, '', '', '', '', '', '', '2017-02-25 13:43:45');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
